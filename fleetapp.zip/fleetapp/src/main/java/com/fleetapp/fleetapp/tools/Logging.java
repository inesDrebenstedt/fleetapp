package com.fleetapp.fleetapp.tools;

import java.io.FileWriter;
import java.io.IOException;  // Import the IOException class to handle errors

public class Logging {
	
	public Logging(String msg)
	{
		writeToLogFile(msg);
	}
	
	
	public void writeToLogFile(String msg)
	{
		try {
		      FileWriter myWriter = new FileWriter("logfile.txt");
		      myWriter.append(msg);
		      myWriter.close();

		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	}

}
