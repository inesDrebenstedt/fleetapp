package com.fleetapp.fleetapp.controllers;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fleetapp.fleetapp.services.EmployeeService;
import com.fleetapp.fleetapp.services.UserService;

@Controller
public class ProfileController {
	
	@Autowired private UserService userService;
	
	@Autowired
	private EmployeeService employeeService;
	
	//Get All Users
//	@GetMapping("/users")
//	public String getUsers()
//	{
//		return "User";
//	}
	
	@RequestMapping(value="/profile")
	public String profile(Model model, Principal principal){	
		//1. get logged in username:
		String un = principal.getName();
		//2. pair logged in user with employee instance (user credentials need to match employee credentials):		
		model.addAttribute("employee", employeeService.findByUsername(un));
		return "profile";
	}	
	
	@RequestMapping(value="/inbox")
	public String inbox(Model model, Principal principal){	
		//1. get logged in username:
		String un = principal.getName();
		//2. pair logged in user with employee instance (user credentials need to match employee credentials):		
		model.addAttribute("employee", employeeService.findByUsername(un));
		return "inbox";
	}
	
	@RequestMapping(value="/timeline")
	public String timeline(Model model, Principal principal){	
		//1. get logged in username:
		String un = principal.getName();
		//2. pair logged in user with employee instance (user credentials need to match employee credentials):		
		model.addAttribute("employee", employeeService.findByUsername(un));
		return "timeline";
	}
	
	@RequestMapping(value="/chat")
	public String chat(Model model, Principal principal){	
		//1. get logged in username:
		String un = principal.getName();
		//2. pair logged in user with employee instance (user credentials need to match employee credentials):		
		model.addAttribute("employee", employeeService.findByUsername(un));
		return "chat";
	}


}
